library(RMySQL)

#Connect to the Database
db <-dbConnect(MySQL(),user='stomlins',password='<pass>',dbname='stomlins_db')

#Send Query
rs <-dbSendQuery(db,"SELECT * from Mart1 LIMIT 5")

#Fetch full results
data <-fetch(rs,n=-1)

#Check what has come back
data
class(data)
typeof(data)

#Interact with database
dbListConnections( dbDriver( drv = "MySQL"))
dbListTables(db)
dbListFields(db,"Mart1")

#Write a data frame as a database table
dbWriteTable(db,name='test2',value=data,overwrite=TRUE)
dbListFields(db,'test2')


#Select from the new table
rs2 <-dbSendQuery(db,"SELECT * FROM test2 LIMIT 5")
 data2 <-fetch(rs2,n=-1)
data2

#Tidy up by closing connections before exiting
ac <- dbListConnections(MySQL())
   for(con in ac){
       dbDisconnect(con)}

dbListConnections(MySQL())
list()




